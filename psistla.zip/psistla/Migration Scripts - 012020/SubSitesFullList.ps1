﻿if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null)
{
Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}
#Web application URL and CSV File location Variables
$SiteColURL="https://intranet.tstech.com/sites/TSMX/"
$CSVFile="C:\PSExports\TSMX_SubSitesFullList.csv"

Get-SPWeb -Site $SiteColURL -Limit ALL | Export-CSV $CSVFile -NoTypeInformation

