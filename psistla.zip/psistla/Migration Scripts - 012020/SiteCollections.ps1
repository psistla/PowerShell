﻿if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null)
{
Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}
#Web application URL and CSV File location Variables
$WebAppURL="https://intranet.tstech.com/"
$CSVFile="C:\PSExports\SitesList.csv"

Get-SPWebApplication $WebAppURL | Get-SPSite -Limit All | ForEach-Object {
    New-Object -TypeName PSObject -Property @{
             SiteName = $_.RootWeb.Title
             Url = $_.Url
             Owner = $_.Owner
             LastModified = $_.LastContentModifiedDate }
} | Export-CSV $CSVFile -NoTypeInformation