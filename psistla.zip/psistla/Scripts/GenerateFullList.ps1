﻿if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null)
{
Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

$WebApp="https://intranet.tstech.com/"
$ExportTo = "C:\PSExports\520\"
$FileType = ".csv"

$SPWebApp = Get-SPWebApplication $WebApp
$Count = 0
foreach ($SPSite in $SPWebApp.Sites)
{
    if ($SPSite -ne $null)
        {
            try
                {
                    $Count++
                    Get-SPWeb -Site $SPSite -Limit ALL | Export-CSV -Path($ExportTo+$Count+$FileType) -NoTypeInformation
                    Write-Host "Exporting Sub Sites Complete for " $SPSite -ForeGroundColor DarkGreen
                }
            catch
                {
                    Write-Host "Exporting Sub Sites Failed for " $SPSite -ForeGroundColor Red
                    $ErrorMessage = $_.Exception.Message
                    Write-Host "ERROR MESSAGE: " $ErrorMessage -ForeGroundColor Yellow
                }
        }
}