﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
 
#Read the CSV file
$CSVData = Import-CSV -path "C:\PSExports\NewISInventory.csv"
$listcount = 0

foreach ($row in $CSVData) 
    {
        if($row.Status -eq "Delete")
            {
                Write-Host "Site Name : " $row.SiteTitle " | List name : " $row.ListLibraryName -ForeGroundColor green
                $listcount += 1
                Delete-SPList $row.SiteURL $row.ListLibraryName
                }
    }
    Write-Host "Lists count : " $listcount -ForeGroundColor yellow


Function Delete-SPList
{
    param
    (
        [string]$WebURL  = $(throw "Please Enter the Web URL!"),
        [string]$ListName = $(throw "Please Enter the List Name to Delete!")
    )
     
    #Get the Objects 
    $Web = Get-SPWeb $WebURL
    $List = $Web.lists[$ListName]
  
    if($List)
    {
        #Set Allow Delete Flag
        $list.AllowDeletion = $true
        $list.Update()
 
        #delete list from sharepoint using powershell - Send List to Recycle bin
        $list.Recycle()
         
        #TO permanently delete a list, Use: 
        #$List.Delete()
 
        Write-Host "List/Library: $($ListName) deleted successfully from: $($WebURL)" -ForeGroundColor green
    }
    else
    {
        Write-Host "List/Library: $($ListName) doesn't exist at $($WebURL)" -ForeGroundColor Magenta
    }
    $web.Dispose() 
}
 
