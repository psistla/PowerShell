﻿if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null)
{
Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

$WebApp="https://intranet.tstech.com/"
$ExportTo = "C:\PSExports\520\"
$FileType = ".csv"

$SPWebApp = Get-SPWebApplication $WebApp
Get-SPSite -WebApp $WebApp -Limit ALL | Select ID, Owner, SecondaryContact, FileNotFoundUrl, Url, LastContentModifiedDate, LastSecurityModifiedDate, RootWeb | Export-CSV -Path($ExportTo+'Sitecollectionsall' +$FileType) -NoTypeInformation