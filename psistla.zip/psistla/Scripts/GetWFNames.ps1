﻿#Load SharePoint 2007 Assemblies
[System.Reflection.Assembly]::Load("Microsoft.SharePoint, Version=12.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c") | out-null

$siteurl="https://intranet.tstech.com/sites/IS"
$site=new-object Microsoft.SharePoint.SPSite($siteurl)

#Initialize Workflow Count variable
$workflowcount = 0

#Foreach loop to loop through all webs, and lists with workflow associations, and exclude workflows that have previous versions and write findings to .csv file.

function Get-Workflows()
{
    foreach($web in $site.AllWebs)
    {
            foreach($list in $web.Lists)
            {
                foreach($wf in $list.WorkflowAssociations)
                {
                        if ($wf.Name -notlike "*Previous Version*")
                        {
                            $hash = @{"[URL]"=$web.Url;"[List Name]"=$list.Title;"[Workflow]"=$wf.Name}
                             New-Object PSObject -Property $hash | Sort-Object

                        }
                }
            }
    }
}

foreach($web in $site.AllWebs)
{
    foreach($list in $web.Lists)
    {
        foreach($wf in $list.WorkflowAssociations)
        {
            if ($wf.Name -notlike "*Previous Version*")
            {
               $workflowcount += 1
            }
        }
    }
}

Get-Workflows | Export-csv C:\PSExports\IS_Workflows.csv
"Workflow Count " + $workflowcount >> C:\PSExports\IS_Workflows.csv

$site.Dispose()