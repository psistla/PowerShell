﻿  if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) 
    {
        Add-PSSnapin "Microsoft.SharePoint.PowerShell"
    }

    Function WriteWFDetails($wfAssociations, $wfType, $listTitle, $OutputFile, $includePreviousVersions) 
    {
        if($includePreviousVersions) {
            $wfAssociations = ($wfAssociations | Sort-Object Name)
        }
        else {
            $wfAssociations = ($wfAssociations | ?{-Not ($_.Name -like "*Previous Version*")} | Sort-Object Name)
        }
        foreach($wfAssociation in $wfAssociations) {
            #$record =",,,$wfType,`"$($listTitle)`",`"$($wfAssociation.Name)`",`"$($wfAssociation.TaskListTitle)`",`"$($wfAssociation.HistoryListTitle)`","
            #$record += "$($wfAssociation.RunningInstances),$($wfAssociation.Created),$($wfAssociation.Modified)"
            Add-Content $OutputFile $record
        }
    }

    Function AllWorkflows($siteUrl, $OutputFile, $includePreviousVersions)
    {
        $siteColl  = Get-SPSite $siteUrl
        Set-Content $OutputFile "WebUrl,SiteWFCount,ListWFCount,SiteWF or ListWF?,ListName,WorkflowName,TaskList,HistoryList,RunningInstances,Created,Modified"

        foreach($web in $siteColl.AllWebs)
        {
            $webUrl = if($web.IsRootWeb) { "$($web.Url) -- RootWeb" } else {  $web.Url }

            if($includePreviousVersions) {
                $siteWFCount = $web.WorkflowAssociations.Count
                $listWFCount = $web.Lists.WorkflowAssociations.Count
            }
            else {
                $siteWFCount = ($web.WorkflowAssociations | ? {-Not ($_.Name -like "*Previous Version*")}).Count
                $listWFCount = ($web.Lists.WorkflowAssociations | Select Name | ? {-Not ($_.Name -like "*Previous Version*")}).Count
            }

            if($listWFCount -gt 0 -or $siteWFCount -gt 0) {
                #$record = "`"$webUrl`",$siteWFCount,$listWFCount"
                Add-Content $OutputFile $record;

                WriteWFDetails $web.WorkflowAssociations "SiteWF" "" $OutputFile $includePreviousVersions

                foreach($list in ($web.Lists | ? {$_.WorkflowAssociations.Count -gt 0}))
                {
                    WriteWFDetails $list.WorkflowAssociations "ListWF" $list.Title $OutputFile $includePreviousVersions
                }
            }
            $web.Dispose()
        }
        $siteColl.Dispose()
        }

    #parameter 3 - pass $TRUE to include previous workflow versions
    AllWorkflows "https://intranet.tstech.com/sites/RnD" "C:\PSExports\RD_WorkflowReport.csv" $FALSE