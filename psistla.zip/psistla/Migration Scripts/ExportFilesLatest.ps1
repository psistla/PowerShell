﻿Add-PSSnapin Microsoft.SharePoint.PowerShell –ErrorAction SilentlyContinue

$Location = "D:\SP13_Archival\CCR"

#Read the CSV file
$CSVData = Import-CSV -path "D:\SP13_Archival\CCR\ArchiveList.csv"
$reqlistcount = 0

foreach ($row in $CSVData) {
    
    #Variables
    $SiteUrl= $row.SiteURL
    $ListName= $row.ListLibraryName
    $DownloadLocation = $Location + "\" + $ListName
    $OutPutFile = $DownloadLocation + "\" + $ListName + ".csv"

    if (!(Test-Path -path $DownloadLocation))
        {
            $dest = New-Item $DownloadLocation -type directory 
        }

 
    #Get the web
    $Web = Get-SPWeb $SiteUrl
    
      
    If($row.Type -eq "Library")
    
    {
        Download-SPDocumentLibrary $SiteURL $ListName $DownloadLocation
    }
    
    else
    {
        #ExportList $SiteURL $ListName $DownloadLocation $OutPutFile
    }

}



Function Download-SPFolder($SPFolderURL, $DownloadPath)
{
    Try {
        #Get the Source SharePoint Folder
        $SPFolder = $web.GetFolder($SPFolderURL)
  
        $DownloadLocation = Join-Path $DownloadLocation $SPFolder.Name 
        #Ensure the destination local folder exists! 
        If (!(Test-Path -path $DownloadLocation))
        {    
            #If it doesn't exists, Create
            $LocalFolder = New-Item $DownloadLocation -type directory 
        }
  
        #Loop through each file in the folder and download it to Destination
        ForEach ($File in $SPFolder.Files) 
        {
            #Download the file
            $Data = $File.OpenBinary()
            $FilePath= Join-Path $DownloadLocation $File.Name
            [System.IO.File]::WriteAllBytes($FilePath, $data)
            Write-host -f Green "`tDownloaded the File:"$File.ServerRelativeURL         
        }
  
        #Process the Sub Folders & Recursively call the function
        ForEach ($SubFolder in $SPFolder.SubFolders)
        {
            #If($SubFolder.Name -ne "Forms") #Leave "Forms" Folder
            #{
                #Call the function Recursively
                Download-SPFolder $SubFolder $DownloadLocation
            #}
        }
    }
    Catch {
        Write-host -f Red "Error Downloading Document Library:" $_.Exception.Message
    }  
}
 
#Main Function
Function Download-SPDocumentLibrary($SiteURL, $ListName, $DownloadLocation)
{
    Try {
       
        #Get the document Library to Download
        $Library = $Web.Lists[$ListName]
        Write-host -f magenta "Downloading Document Library:" $Library.Title
 
         #Call the function to download the document library
        Download-SPFolder -SPFolderURL $Library.RootFolder.Url -DownloadPath $DownloadLocation
 
        Write-host -f Green "*** Download Completed  ***"
        }

        Catch
        {
            Write-host -f Red "Error Downloading Document Library:" $_.Exception.Message
        }  
}



