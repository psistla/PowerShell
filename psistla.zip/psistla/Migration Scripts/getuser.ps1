﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

#Get-ADUser -Identity 's-1-5-21-7431124-966598516-604069369-26132'

#((New-Object System.Security.Principal.SecurityIdentifier ($UserSid)).Translate( [System.Security.Principal.NTAccount])).Value

#$UserSid = s-1-5-21-7431124-966598516-604069369-26132
#((New-Object System.Security.Principal.SecurityIdentifier ("s-1-5-21-7431124-966598516-604069369-26132")).Translate( [System.Security.Principal.NTAccount])).Value

#$u = New-Object System.Security.Principal.SecurityIdentifier("s-1-5-21-7431124-966598516-604069369-26132")
#Write-host $u. -ForegroundColor green


$objSID = New-Object System.Security.Principal.SecurityIdentifier('s-1-5-21-7431124-966598516-604069369-26132')
    $objUser = $objSID.Translate( [System.Security.Principal.NTAccount])
    $objUser.Value