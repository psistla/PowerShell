﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

$reqSite = Get-SPSite "https://intranet.tstech.com/sites/IS"
$reqSite.LockIssue = "This site is locked due to Migration. For more information please contact: Josh Barton [josh.barton@tstech.com] or AJ Lallathin [angeline.lallathin@tstech.com]"
set-spsite $reqSite -LockState ReadOnly
