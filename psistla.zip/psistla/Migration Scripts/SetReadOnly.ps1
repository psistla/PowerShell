﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
 
$siteUrl = “https://intranet.tstech.com/sites/RnD”
$lstatus = $true

if($lstatus)
    {
        #$reqsite = Get-SPSite -Identity $siteUrl

        #$reqsite.LockIssue = "Locked due to Migration"

        set-spsite $siteUrl -LockState ReadOnly
        
    }

else
    {
        set-spsite $siteUrl -LockState Unlock
    }

Write-Host $siteurl " lock status set : " $lstatus -ForeGroundColor Yellow