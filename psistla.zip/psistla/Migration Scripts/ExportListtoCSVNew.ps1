﻿Add-PSSnapin Microsoft.SharePoint.PowerShell –ErrorAction SilentlyContinue

$Location = "D:\SP13_Archival\RD"

#Read the CSV file
$CSVData = Import-CSV -path "D:\SP13_Archival\RD\ArchiveList.csv"

foreach ($row in $CSVData) {
    
    #Variables
    $SiteUrl= $row.SiteURL
    $ListName= $row.ListLibraryName
    $DownloadLocation = $Location + "\" + $ListName
    $OutPutFile = $DownloadLocation + "\" + $ListName + ".csv"

    if (!(Test-Path -path $DownloadLocation))
        {
            $dest = New-Item $DownloadLocation -type directory 
        }

 
    #Get the web
    $Web = Get-SPWeb $SiteUrl
    
      
    If($row.Type -eq "List")
    
    {
        #Get Web and List
        $web = Get-SPWeb $SiteUrl
        $List = $Web.Lists[$ListName]
        Write-host "Total Number of Items Found:"$List.Itemcount
 
        #Array to Hold Result - PSObjects
        $ListItemCollection = @()
   
        #Get All List items 
        $List.Items | ForEach {
        write-host "Processing Item ID:"$_["ID"]
  
        $ExportItem = New-Object PSObject 
        #Get Each field
        foreach($Field in $_.Fields)
            {
                $ExportItem | Add-Member -MemberType NoteProperty -name $Field.InternalName -value $_[$Field.InternalName]  
            }
        #Add the object with property to an Array
        $ListItemCollection += $ExportItem
 
        }    

    #Export the result Array to CSV file
    $ListItemCollection | Export-CSV $OutPutFile -NoTypeInformation
    Write-host -f Green "List '$ListName' Exported to $($OutputFile) for site $($SiteURL)"
    }
    
    else
    {
        #Download-SPDocumentLibrary $SiteURL $ListName $DownloadLocation
    }

}