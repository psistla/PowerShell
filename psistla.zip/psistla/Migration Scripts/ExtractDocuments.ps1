﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

#Read the CSV file to get information
$CSVData = Import-CSV -path "C:\PSExports\Inventory_Archive.csv"
$reqlistcount = 0

foreach ($row in $CSVData) 
    {
        if($row.Status -eq "Archive")
            {
                
                if($list.BaseType -eq "DocumentLibrary")
		{
                Write-Host "...Checking Site : " $row.SiteURL -ForeGroundColor Cyan
                Write-Host "......Checking List : " $row.ListLibraryName "`n" -ForeGroundColor Cyan
                $reqlistcount += 1
                
                # Runtime-Variables
                $SiteURL = $row.SiteURL
                $SiteName = "Testing"
                $LibraryName = $row.ListLibraryName

                # Create folders if doesn't exist
                $rootdir = "D:\SP13_Archival\IS"
                $DownloadPath = $rootdir + "\" + $SiteName
                
                #$DownloadPath = $rootdir
                Write-host -ForegroundColor green "location directory: " $DownloadPath

                If(!(test-path $DownloadPath))
                    {
                    New-Item -ItemType Directory -Force -Path $DownloadPath
                    }

             
         }   #Download-SPDocumentLibrary $SiteURL $LibraryName $DownloadPath
            }
    }
    
#Write-Host " ### Count of lists read identified from CSV File : " $reqlistcount -ForeGroundColor Black -BackgroundColor DarkYellow



# Runtime-Variables
#$SiteURL = "https://intranet.tstech.com/sites/IS/IT/"
#$SiteName = "Testing"
#$LibraryName ="Incident and Problem Documents"




#Call the Function to export all document libraries from a site
#Download-SPDocumentLibrary $SiteURL $LibraryName $DownloadPath


#All function are here --------------------------->

#To download Document library
Function Download-SPDocumentLibrary($SiteURL, $LibraryName, $DownloadPath)
{
    Try {
        #Get the  Web
        $Web = Get-SPWeb $SiteURL
 
        #Delete any existing files and folders in the download location
        If (Test-Path $DownloadPath) {Get-ChildItem -Path $DownloadPath -Recurse| ForEach-object {Remove-item -Recurse -path $_.FullName }}
 
        #Get the document Library to Download
        $Library = $Web.Lists[$LibraryName]
        Write-host -f magenta "Downloading Document Library:" $Library.Title
 
         #Call the function to download the document library
        Download-SPFolder -SPFolderURL $Library.RootFolder.Url -DownloadPath $DownloadPath
 
        Write-host -f Green "*** Download Completed  ***"
    }
    Catch {
        Write-host -f Red "Error Downloading Document Library:" $_.Exception.Message
    }  
}

#To Download All Files from a SharePoint Folder
Function Download-SPFolder($SPFolderURL, $DownloadPath)
{
    Try {
        #Get the Source SharePoint Folder
        $SPFolder = $web.GetFolder($SPFolderURL)
  
        $DownloadPath = Join-Path $DownloadPath $SPFolder.Name 
        #Ensure the destination local folder exists! 
        If (!(Test-Path -path $DownloadPath))
        {    
            #If it doesn't exists, Create
            $LocalFolder = New-Item $DownloadPath -type directory 
        }
  
        #Loop through each file in the folder and download it to Destination
        ForEach ($File in $SPFolder.Files) 
        {
            #Download the file
            $Data = $File.OpenBinary()
            $FilePath= Join-Path $DownloadPath $File.Name
            [System.IO.File]::WriteAllBytes($FilePath, $data)
            Write-host -f Green "`tDownloaded the File:"$File.ServerRelativeURL         
        }
  
        #Process the Sub Folders & Recursively call the function
        ForEach ($SubFolder in $SPFolder.SubFolders)
        {
            If($SubFolder.Name -ne "Forms") #Leave "Forms" Folder
            {
                #Call the function Recursively
                Download-SPFolder $SubFolder $DownloadPath
            }
        }
    }
    Catch {
        Write-host -f Red "Error Downloading Document Library:" $_.Exception.Message
    }  
}
 

