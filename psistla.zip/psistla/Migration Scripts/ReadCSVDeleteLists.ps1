﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
 
#Read the CSV file
$CSVData = Import-CSV -path "C:\PSExports\Migration-09092020\IS-Inventory.csv"
$reqlistcount = 0

foreach ($row in $CSVData) 
    {
        if($row.Status -eq "Migrate")
            {
                Write-Host "...Checking Site : " $row.SiteURL -ForeGroundColor Cyan
                Write-Host "......Checking List : " $row.ListLibraryName "`n" -ForeGroundColor Cyan
                $reqlistcount += 1
                #Delete-SPList $row.SiteURL $row.ListLibraryName
            }
    }
    
Write-Host " ### Count of lists read identified from CSV File : " $reqlistcount -ForeGroundColor Black -BackgroundColor DarkYellow


Function Delete-SPList
{
    param
    (
        [string]$WebURL  = $(throw "Please Enter the Web URL!"),
        [string]$ListName = $(throw "Please Enter the List Name to Delete!")
    )
     
    #Get the Objects 
    $Web = Get-SPWeb $WebURL
    $List = $Web.lists[$ListName]
  
    if($List)
    {
        
        try
                {
                    #Set Allow Delete Flag
                    $list.AllowDeletion = $true
                    $list.Update()
 
                    #To delete list from sharepoint using powershell - Send List to Recycle bin
                    $list.Recycle()
                    Write-Host "SEND TO RECYCLE-BIN >>> SUCCESS >>> List/Library : $($ListName) >>> Site : $($WebURL) `n" -ForeGroundColor green
                    
         
                    #To permanently delete a list, Use: 
                    #$List.Delete()
                    #Write-Host "LIST DELETION >>> SUCCESS >>> List/Library : $($ListName) >>> Site : $($WebURL) `n" -ForeGroundColor green

                }

        catch
                {
                    Write-Host $ListName -ForeGroundColor Magenta
                    $ErrorMessage = $_.Exception.Message
                    Write-Host "ERROR MESSAGE: " $ErrorMessage "`n" -ForeGroundColor Red
                }      
 
        
    }

    else
    {
        Write-Host "LIST DOESN'T EXIST IN THIS SITE. `n" -ForeGroundColor Yellow
        Write-Host " " -ForeGroundColor Yellow
    }
   
    $web.Dispose() 
}




