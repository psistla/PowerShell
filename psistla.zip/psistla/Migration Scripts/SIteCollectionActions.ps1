﻿param
(
[Parameter(Mandatory=$true)] [string] $SiteCol
)
 
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null)
{
Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

foreach ($SPSite in $SiteCol.Sites)
{

if ($SPSite -ne $null)

{

try
{

}

catch
{
Write-Host "Your message" -ForeGroundColor Red
$ErrorMessage = $_.Exception.Message
Write-Host "ERROR MESSAGE: " $ErrorMessage -ForeGroundColor Yellow
}

}

}
